TRUNCATE TABLE proizvodi;

INSERT INTO proizvodi (naziv, cena, slika) VALUES
('AMD Ryzen 9 9950X3D 4.3 GHz', 105000, 'image6.jpg'),
('WESTERN DIGITAL Red SN700 500GB SSD', 7000, 'image10.jpg'),
('AMD Ryzen 9 7900 3.7GHz', 57000, 'image5.jpg'),
('WESTERN DIGITAL SN7100 Black 1TB SSD', 10000, 'image12.jpg'),
('AMD Ryzen 7 9800X3D 4.70GHz ', 79000, 'image77.jpg'),
('WESTERN DIGITAL Green SN3000 2TB  SSD', 15000, 'image11.jpg'),
('INTEL Core i3-12100 3.30 GHz', 15000, 'image4.jpg'),
('INTEL Core i5-12400 2.50 GHz ', 21000, 'image2.jpg'),
('AMD Ryzen 9 9950X3D 4.3 GHz', 105000, 'image6.jpg'),
('WESTERN DIGITAL Red SN700 500GB SSD', 7000, 'image10.jpg'),
('AMD Ryzen 9 7900 3.7GHz', 57000, 'image5.jpg'),
('WESTERN DIGITAL SN7100 Black 1TB SSD', 10000, 'image12.jpg'),
('AMD Ryzen 7 9800X3D 4.70GHz ', 79000, 'image77.jpg'),
('GeForce RTX 4070 12GB GDDR6', 85000, 'image88.jpg'),
('Procesor Intel Core i7-14700F 5.40GHz Box', 45000, 'image55.jpg'),
('BIOSTAR GTX 1660 Ti 6GB GDDR6 ', 28000, 'image99.jpg'),
('INTEL Pentium Gold G6400 4.00 GHz', 10000, 'image44.jpg'),
('Pure Rock 3 LX Procesorsko hlađenje', 5000, 'image15.jpg'),
('WESTERN DIGITAL Red Pro 4TB SATA III 3.5', 22000, 'image43.jpg'),
('Pure Rock 3 LX Procesorsko hlađenje', 5000, 'image15.jpg');

('INTEL Pentium Gold G6400 4.00 GHz', 10000, 'image44.jpg'),
('Pure Rock 3 LX Procesorsko hlađenje', 5000, 'image15.jpg'),
('WESTERN DIGITAL Red Pro 4TB SATA III 3.5', 22000, 'image53.jpg'),
('BE QUIET! Light Loop 240mm White', 5000, 'image15.jpg');