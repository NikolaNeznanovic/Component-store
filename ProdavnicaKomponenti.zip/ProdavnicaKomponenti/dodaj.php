<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $ime = trim($_POST['ime']);
    $email = trim($_POST['email']);

    if (!empty($ime) && !empty($email)) {
       
        $stmt = $conn->prepare("INSERT INTO korisnici (ime, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $ime, $email);
        
        if ($stmt->execute()) {
            
            header("Location: korisnici.php");
            exit();
        } else {
            echo "Greška pri dodavanju korisnika: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Sva polja su obavezna.";
    }
} else {
    echo "Neispravan zahtev.";
}
?>
