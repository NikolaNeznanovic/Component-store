<?php
session_start();
$greska = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $conn = new mysqli("localhost", "root", "", "mojabaza");
    if ($conn->connect_error) {
        die("Greška: " . $conn->connect_error);
    }
    $ime = $_POST["ime"];
    $prezime = $_POST["prezime"];
    $email = $_POST["email"];
    $lozinka = password_hash($_POST["lozinka"], PASSWORD_DEFAULT);
    $stmt = $conn->prepare("SELECT id FROM korisnici WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $rez = $stmt->get_result();

    if ($rez->num_rows > 0) {
        $greska = "Korisnik sa tom email adresom već postoji.";
    } else {
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO korisnici (ime, prezime, email, lozinka) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $ime, $prezime, $email, $lozinka);

     
    if ($stmt->execute()) {
        $poruka = "Uspešno ste se registrovali.";
    } else {
        $poruka = "Greška prilikom registracije.";
    }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Registracija</title>
    <link rel="stylesheet" href="style.css"> 
</head>
<body>

<div class="login-box">
    <div class="login-header">
        <header>Registracija</header>
    </div>
<?php if (!empty($poruka)): ?>
    <p style="color: green; margin-bottom: 20px; text-align: center;"><?= htmlspecialchars($poruka) ?></p>
<?php endif; ?>
    <?php if (!empty($greska)): ?>
        <p style="color: red; text-align: center; margin-bottom: 20px;"><?= htmlspecialchars($greska) ?></p>
    <?php endif; ?>

<nav class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Logo" class="logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Početna</a></li>
            <li><a href="onama.php">O nama</a></li>
            <li><a href="kontakt.php">Kontakt</a></li> 
        </ul>
</nav>

    <form method="POST" action="registracija.php">
        <div class="input-box">
            <input type="text" class="input-field" name="ime" placeholder="Ime" required>
            <input type="text" class="input-field" name="prezime" placeholder="Prezime" required>
            <input type="email" class="input-field" name="email" placeholder="Email adresa" required>
            <input type="password" class="input-field" name="lozinka" placeholder="Lozinka" required>
        </div>

        <div class="input-submit">
            <button type="submit" class="submit-btn">Registruj se</button>
        </div>

        <div class="sign-up-link">
            <p>Već imate nalog? <a href="login.php">Prijavite se</a></p>
        </div>
    </form>
</div>

</body>
</html>
