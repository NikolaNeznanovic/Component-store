<?php
$poruka = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"] ?? '';
    $lozinka = $_POST["lozinka"] ?? '';
    $potvrda = $_POST["potvrda_lozinka"] ?? '';

    if (empty($email) || empty($lozinka) || empty($potvrda)) {
        $poruka = "Sva polja su obavezna.";
    } elseif ($lozinka !== $potvrda) {
        $poruka = "Lozinke se ne poklapaju.";
    } else {
        $conn = new mysqli("localhost", "root", "", "mojabaza");
        if ($conn->connect_error) {
            die("Greška: " . $conn->connect_error);
        }
        $stmt = $conn->prepare("SELECT id FROM korisnici WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $rezultat = $stmt->get_result();

        if ($rezultat->num_rows === 1) {
            $hesirana = password_hash($lozinka, PASSWORD_DEFAULT);
            $stmt2 = $conn->prepare("UPDATE korisnici SET lozinka = ? WHERE email = ?");
            $stmt2->bind_param("ss", $hesirana, $email);
            if ($stmt2->execute()) {
                $poruka = "Uspešno ste promenili lozinku.";
            } else {
                $poruka = "Greška pri promeni lozinke.";
            }
            $stmt2->close();
        } else {
            $poruka = "Korisnik sa tim emailom ne postoji.";
        }

        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Zaboravljena sifra</title>
    <link rel="stylesheet" href="style.css?v=2"> 
</head>
<body>
    <nav class="navbar">
            <div class="logo">
                <img src="img/logo.png" alt="Logo" class="logo">
            </div>
            <ul class="nav-links">
                <li><a href="index.php">Početna</a></li>
                
                <li><a href="onama.php">O nama</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>

                <?php if (isset($_SESSION['imePrezime'])): ?>
                   
                 
                    
                <?php else: ?>
                  
                <?php endif; ?>
            </ul>
            <div class="menu-icon" id="menu-icon">
                <span>&#9776;</span>
            </div>
        </nav>
        <div class="cart-container">
    <div class="login-box">
  <div class="login-header">
    <header>Zaboravljena sifra</header>
  </div>
  <div class="input-box">
    <form method="POST" action="sifra.php">
      <input type="email" name="email" placeholder="Vaš email" required class="input-field">
      <input type="password" name="lozinka" placeholder="Nova lozinka" required class="input-field">
      <input type="password" name="potvrda_lozinka" placeholder="Potvrdi lozinku" required class="input-field">
      <button type="submit" class="submit-btn">Promeni lozinku</button>
    </form>
  </div>
</div>


<?php if (!empty($poruka)): ?>
    <p style="color: green;"><?= htmlspecialchars($poruka) ?></p>
<?php endif; ?>


<?php if (isset($poruka)): ?>
    <p style="color:green;"><?= htmlspecialchars($poruka) ?></p>
<?php endif; ?>


</div>

</body>
</html>