<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['azuriraj_kolicinu'])) {
    $index = $_POST['index'];
    $nova_kolicina = (int)$_POST['nova_kolicina'];
    if ($nova_kolicina > 0 && isset($_SESSION['korpa'][$index])) {
        $_SESSION['korpa'][$index]['kolicina'] = $nova_kolicina;
    }
    header("Location: korpa.php");
    exit();
}

if (!isset($_SESSION['korpa'])) {
    $_SESSION['korpa'] = [];
}

if (isset($_GET['ukloni'])) {
    $index = $_GET['ukloni'];
    unset($_SESSION['korpa'][$index]);
    $_SESSION['korpa'] = array_values($_SESSION['korpa']); 
    header("Location: korpa.php");
    exit();
}

$kupovinaUspesna = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kupi'])) {
    $_SESSION['korpa'] = []; 
    $kupovinaUspesna = true;
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Korpa</title>
    <link rel="stylesheet" href="style.css">
 
</head>
<body>
<style>
.cart-container {
    max-width: 900px;
    margin: 40px auto;
    background: #fff;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
    border-radius: 12px;
    padding: 30px;
}
.cart-title {
    font-size: 28px;
     margin-bottom: 20px;
    font-weight: bold;
    text-align: center;
}
table {
    width: 100%;
    border-collapse: collapse;
    }
th, td {
    padding: 14px;
    text-align: center;
    border-bottom: 1px solid #ddd;
}
th {
    background-color: #222;
    color: white;
 }
 img {
     width: 60px;
     height: auto;
     border-radius: 6px;
}
.remove-btn {
    background-color: #e74c3c;
    border: none;
    color: white;
    padding: 8px 14px;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.2s ease;
}
.remove-btn:hover {
    background-color: #c0392b;
}
.buy-btn {
    background-color: #27ae60;
    border: none;
    color: white;
    padding: 10px 24px;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.2s ease;
    font-size: 16px;
}
.buy-btn:hover {
background-color: #1e8449;
}
.empty-message {
    text-align: center;
    padding: 40px;
    font-size: 20px;
    color: #555;
}
.total-price {
    text-align: right;
    font-size: 18px;
    font-weight: bold;
    padding-top: 15px;
}
.success-message {
    text-align: center;
    color: green;
    font-weight: bold;
    margin-bottom: 20px;
}
</style>
<nav class="navbar">
    <div class="logo">
        <img src="img/logo.png" alt="Logo" class="logo">
    </div>
    <ul class="nav-links">
        <li><a href="korisnik.php">Proizvodi</a></li>
        <li><a href="korpa.php">Korpa</a></li>
        <li><a href="logout.php">Odjava</a></li>
    </ul>
</nav>

<div class="cart-container">
    <div class="cart-title">Moja korpa</div>

    <?php if ($kupovinaUspesna): ?>
        <div class="success-message">Uspešno ste kupili proizvode!</div>
    <?php endif; ?>

    <?php if (empty($_SESSION['korpa'])): ?>
        <div class="empty-message">Vaša korpa je prazna.</div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Slika</th>
                    <th>Naziv</th>
                    <th>Cena</th>
                    <th>Količina</th>
                    <th>Ukloni</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $ukupno = 0;
                foreach ($_SESSION['korpa'] as $index => $stavka): 
                    $ukupno += $stavka['cena'] * $stavka['kolicina'];
                ?>
                    <tr>
    <td><img src="img/<?php echo htmlspecialchars($stavka['slika']); ?>" alt=""></td>
    <td><?php echo htmlspecialchars($stavka['naziv']); ?></td>
    <td><?php echo number_format($stavka['cena'], 0, ',', '.'); ?> RSD</td>
    <td>
        <form method="POST" action="korpa.php" style="display:inline-block;">
            <input type="hidden" name="index" value="<?php echo $index; ?>">
            <input type="number" name="nova_kolicina" min="1" value="<?php echo $stavka['kolicina']; ?>" style="width: 50px;">
            <button type="submit" name="azuriraj_kolicinu" class="update-btn">Ažuriraj</button>
        </form>
    </td>
    <td>
        <a href="korpa.php?ukloni=<?php echo $index; ?>">
            <button class="remove-btn">Ukloni</button>
        </a>
    </td>
</tr>

                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total-price">Ukupno: <?php echo number_format($ukupno, 0, ',', '.'); ?> RSD</div>

        <form method="POST" style="text-align: right; margin-top: 20px;">
            <button type="submit" name="kupi" class="buy-btn">Kupi</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>