<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mojabaza";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Konekcija nije uspela: " . $conn->connect_error);
}

$id = (int)$_POST['id'];
$naziv = $_POST['naziv'];
$cena = $_POST['cena'];
//Da li je korisnik uspesno upload sliku
if (isset($_FILES['slika']) && $_FILES['slika']['error'] == 0) {
    $target_dir = "img/";
    $file_name = basename($_FILES["slika"]["name"]);
    $target_file = $target_dir . $file_name;

    // Da li je fajl zaista slika
    $check = getimagesize($_FILES["slika"]["tmp_name"]);
    if ($check === false) {
        die("Fajl nije slika.");
    }

    if (move_uploaded_file($_FILES["slika"]["tmp_name"], $target_file)) {
        
        $sql = "UPDATE proizvodi SET naziv = ?, cena = ?, slika = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdsi", $naziv, $cena, $file_name, $id);
    } else {
        die("Greška pri otpremanju fajla.");
    }
} else {
    
    $sql = "UPDATE proizvodi SET naziv = ?, cena = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdi", $naziv, $cena, $id);

}

if ($stmt->execute()) {
    echo "Uspešno izmenjeno.";
    header("Location: admin.php");
    exit();
} else {
    echo "Greška pri izmeni: " . $conn->error;
}

$conn->close();
?>
