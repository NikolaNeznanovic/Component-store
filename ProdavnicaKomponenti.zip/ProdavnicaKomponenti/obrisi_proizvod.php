<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mojabaza";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Konekcija nije uspela: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];

    $sql = "DELETE FROM proizvodi WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: admin.php?msg=obrisano");
        exit;
    } else {
        echo "Greška pri brisanju: " . $conn->error;
    }
} else {
    echo "Nevažeći zahtev.";
}

$conn->close();
?>
