<?php
session_start();
if (!isset($_SESSION['imePrezime'])) {
    header("Location: index.php");
    exit();
}
$mysqli = new mysqli("localhost", "root", "", "mojabaza");
if ($mysqli->connect_error) {
    die("Greška pri povezivanju: " . $mysqli->connect_error);
}
$sql = "SELECT * FROM proizvodi";
$result = $mysqli->query($sql);
$proizvodi = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $proizvodi[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prodavnica Komponenti</title>
    <link rel="stylesheet" href="style.css?v=2">
</head>
<body>
<nav class="navbar">
    <div class="logo">
        <img src="img/logo.png" alt="Logo" class="logo">
    </div>
    <ul class="nav-links">
        <li><a href="index.php">Početna</a></li>
        <li><a href="korisnik.php">Proizvodi</a></li>
        <li><a href="onama.php">O nama</a></li>
        <?php if (isset($_SESSION['imePrezime'])): ?>
            <li><a href="kontakt.php">Kontakt</a></li>
        <?php endif; ?>
        <li><a href="korpa.php">Korpa</a></li>
    </ul>
    <div class="menu-icon" id="menu-icon">
        <span>&#9776;</span>
    </div>
</nav>
<div class="product-container">
    <?php foreach ($proizvodi as $proizvod): ?>
        <div class="product">
            <div class="product-content">
                <img src="img/<?php echo $proizvod['slika']; ?>" alt="<?php echo htmlspecialchars($proizvod['naziv']); ?>">
                <h3><?php echo htmlspecialchars($proizvod['naziv']); ?></h3>
                <p class="price">RSD <?php echo number_format($proizvod['cena'], 0, ',', '.'); ?></p>
            </div>

            <form action="dodaj_u_korpu.php" method="post">
                <input type="hidden" name="naziv" value="<?php echo htmlspecialchars($proizvod['naziv']); ?>">
                <input type="hidden" name="cena" value="<?php echo (int)$proizvod['cena']; ?>">
                <input type="hidden" name="slika" value="<?php echo htmlspecialchars($proizvod['slika']); ?>">
                <input type="hidden" name="proizvod_id" value="<?php echo (int)$proizvod['id']; ?>">
                <button class="add-to-cart-btn" type="submit">Dodaj u korpu</button>
            </form>
        </div>
    <?php endforeach; ?>
</div>
<footer class="footer">
    <p>&copy; 2025 Prodavnica Komponenti</p>
</footer>
</body>
</html>
