<?php
session_start();
if (!isset($_SESSION['uloga']) || $_SESSION['uloga'] !== 'admin') {
    header("Location: index.php");
    exit;
}
$mysqli = new mysqli("localhost", "root", "", "mojabaza");
if ($mysqli->connect_error) {
    die("Greška pri povezivanju: " . $mysqli->connect_error);
}
$sql = "SELECT * FROM proizvodi";
$result = $mysqli->query($sql);
$proizvodi = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $proizvodi[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Proizvodi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css?v=2">
</head>
<body>
<nav class="navbar">
    <div class="logo">
        <img src="img/logo.png" alt="Logo" class="logo">
    </div>
    <ul class="nav-links">
        
        <li><a href="admin.php">Admin Panel</a></li>
        <li><a href="korisnici.php">Korisnici</a></li>
        <li><a href="logout.php">Odjavi se</a></li>
    </ul>
</nav>

<div class="product-container">
    <?php foreach ($proizvodi as $index => $proizvod): ?>
        <div class="product">
            <div class="product-content">
                <img src="img/<?php echo $proizvod['slika']; ?>" alt="<?php echo $proizvod['naziv']; ?>">
                <h3><?php echo $proizvod['naziv']; ?></h3>
                <p class="price">RSD <?php echo number_format($proizvod['cena'], 0, ',', '.'); ?></p>

       <form action="obrisi_proizvod.php" method="post" onsubmit="return confirm('Da li ste sigurni da želite da obrišete ovaj proizvod?');">
    <input type="hidden" name="id" value="<?php echo (int)$proizvod['id']; ?>">
    <button type="submit" class="delete-btn">Obriši</button>
</form>

<form action="izmeni_proizvod.php" method="post" onsubmit="return confirm('Da li ste sigurni da želite da izmenite ovaj proizvod?');">
    <input type="hidden" name="id" value="<?php echo (int)$proizvod['id']; ?>">
<a href="izmene.php?id=<?php echo (int)$proizvod['id']; ?>" class="change-btn">Izmeni</a>
</form>
        </div>
        </div>
    <?php endforeach; ?>
</div>
<footer class="footer">
    <p>&copy; 2025 Prodavnica Komponenti</p>
</footer>
</body>
</html>