<?php
include 'db.php';
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); 
    $sql = "DELETE FROM korisnici WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
       
        header("Location: korisnici.php"); 
        exit();
    } else {
        echo "Greška prilikom brisanja: " . $conn->error;
    }
} else {
    echo "ID korisnika nije prosleđen.";
}
?>
