<?php
session_start();
$conn = new mysqli("localhost", "root", "", "mojabaza"); 
if ($conn->connect_error) {
    die("Greška pri konekciji: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['username'] ?? '';
    $lozinka = $_POST['password'] ?? '';
    $sql = "SELECT * FROM korisnici WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $rezultat = $stmt->get_result();
    if ($rezultat->num_rows === 1) {
        $korisnik = $rezultat->fetch_assoc();

        if ($lozinka === $korisnik['lozinka']) {
            $_SESSION['imePrezime'] = $korisnik['ime'];
            $_SESSION['uloga'] = ($korisnik['email'] === 'admin@email.com') ? 'admin' : 'korisnik';
            if ($_SESSION['uloga'] === 'admin') {
                header("Location: admin.php");
            } else {
                header("Location: korisnik.php");
            }
            exit();
        } else {
            echo "<script>alert('Pogrešna lozinka!'); window.location.href='index.html';</script>";
        }
    } else {
        echo "<script>alert('Korisnik nije pronađen!'); window.location.href='index.html';</script>";
    }
} else {
    header("Location: index.php");
    exit();
}
?>
