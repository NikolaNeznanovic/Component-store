<?php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="sr">
<head>

    <meta charset="UTF-8">
    <title>Korisnici</title>
    <link rel="stylesheet" href="style.css?v=2">

</head>
<body>
<div style="text-align: center; margin-top: 10px;">
    <a href="admin.php">
    <button onclick="location.href='admin.php'" style="padding: 10px 20px; background-color: green; color: white; border: none; border-radius: 5px;">
    Vrati se na Admin Panel
</button>
    </a>
</div>

<h2 style="text-align:center;">Lista korisnika</h2>
<table class="user-table">
    <tr>
        <th>ID</th>
        <th>Ime</th>
        <th>Email</th>
        <th>Akcija</th>
    </tr>

    <?php
    
    $result = $conn->query("SELECT * FROM korisnici");

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['ime']}</td>
                <td>{$row['email']}</td>
                <td><a href='obrisi.php?id={$row['id']}' onclick='return confirm(\"Obrisati korisnika?\")'>Obriši</a></td>
              </tr>";
    }
    ?>
</table>

<form method="post" action="dodaj.php" class="form-container">
    <h2>Dodaj korisnika</h2>
    <input type="text" name="ime" placeholder="Ime" required>
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit">Dodaj</button>
</form>


</body>
</html>
