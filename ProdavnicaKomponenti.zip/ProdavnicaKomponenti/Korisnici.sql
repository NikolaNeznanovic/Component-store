SHOW CREATE TABLE korisnici;
ALTER TABLE korisnici MODIFY COLUMN id INT NOT NULL AUTO_INCREMENT;
ALTER TABLE korisnici ADD PRIMARY KEY (id);
ALTER TABLE korisnici ADD COLUMN prezime VARCHAR(255) NOT NULL AFTER ime;

SHOW CREATE TABLE korisnici;


INSERT INTO korisnici (email, lozinka, ime) VALUES
('marko.markovic@email.com', '123', 'Marko Marković'),
('petar.petrovic@email.com', 'abc', 'Petar Petrović'),
('jovana.j@email.com', '456', 'Jovana Jovanović'),
('ana.anic@email.com', '789', 'Ana Anić'),
('luka.lukic@email.com', '000', 'Luka Lukić');

