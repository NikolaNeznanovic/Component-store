<?php
session_start();

$korisnici = [
    'admin' => '1',
    'korisnik' => '1'
];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (isset($korisnici[$username]) && $korisnici[$username] === $password) {
        $_SESSION['imePrezime'] = $username; 
        $_SESSION['uloga'] = ($username === 'admin') ? 'admin' : 'korisnik';

    if ($username === 'admin') {
        header("Location: admin.php");
    } else {
        header("Location: korisnik.php");
    }
    exit();
    }     else {
      
    echo "<script>alert('Pogrešno korisničko ime ili lozinka!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Komponente shop</title>
</head>
<body>


<form class="login-box" action="index.php" method="POST">
    <div class="login-header">
        <header>Login</header>
        <nav class="navbar">
            <div class="logo">
                <img src="img/logo.png" alt="Logo" class="logo">
            </div>
            <ul class="nav-links">
                <li><a href="index.php">Početna</a></li>
                
                <li><a href="onama.php">O nama</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>

                <?php if (isset($_SESSION['imePrezime'])): ?>
                   
                 
                    
                <?php else: ?>
                  
                <?php endif; ?>
            </ul>
            <div class="menu-icon" id="menu-icon">
                <span>&#9776;</span>
            </div>
        </nav>
    </div>

    <div class="input-box">
        <input type="text" name="username" class="input-field" placeholder="Username" autocomplete="off" required>
    </div>
    <div class="input-box">
        <input type="password" name="password" class="input-field" placeholder="Password" autocomplete="off" required>
    </div>

    <div class="forgot">
        <section>
            <input type="checkbox" id="check">
            <label for="check">Zapamti</label>
        </section>
        <section>
            <a href="sifra.php">Zaboravljena sifra</a>
        </section>
    </div>

    <div class="input-submit">
        <button type="submit" class="submit-btn">Prijavite se</button>
    </div>

    <div class="sign-up-link">
        <p>Nemas nalog? <a href="registracija.php">Registruj se</a></p>
    </div>
</form>

</body>
</html>
