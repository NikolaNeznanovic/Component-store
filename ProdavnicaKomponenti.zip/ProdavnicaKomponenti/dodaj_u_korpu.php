<?php
session_start();
$proizvod_id = $_POST['proizvod_id'];
$naziv = $_POST['naziv'];
$cena = $_POST['cena'];
$slika = $_POST['slika'];
$kolicina = isset($_POST['kolicina']) ? (int)$_POST['kolicina'] : 1;

$proizvod = [
    'proizvod_id' => $proizvod_id,
    'naziv' => $naziv,
    'cena' => $cena,
    'slika' => $slika,
    'kolicina' => $kolicina
];

if (!isset($_SESSION['korpa'])) {
    $_SESSION['korpa'] = [];
}

$found = false;

foreach ($_SESSION['korpa'] as &$item) {
    if ($item['proizvod_id'] == $proizvod_id) {
        $item['kolicina'] += $kolicina;
        $found = true;
        break;
    }
}

if (!$found) {
    $_SESSION['korpa'][] = $proizvod;
}

header("Location: korisnik.php");
exit();
