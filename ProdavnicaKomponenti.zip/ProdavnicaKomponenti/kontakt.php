<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontakt</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <nav class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Logo" class="logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Početna</a></li>
            <li><a href="korisnik.php">Proizvodi</a></li>
            <li><a href="onama.php">O nama</a></li>
            <li><a href="kontakt.php">Kontakt</a></li> 
           
        
        </ul>
    </nav>
    
    <div class="contact-info">
        <h1>Kontakt informacije</h1>
        <p><strong>Adresa:</strong> Jurija Gagarina, Beograd, Srbija</p>
        <p><strong>Telefon:</strong> +381 64 123 4567</p>
        <p><strong>Email:</strong> komponente.shop@gmail.com</p>

        <h2>Radno vreme:</h2>
        <p>Pon - Pet: 09:00 - 18:00</p>
        <p>Subota: 10:00 - 14:00</p>
        <p>Nedelja: Zatvoreno</p>
    </div>

</body>
</html>