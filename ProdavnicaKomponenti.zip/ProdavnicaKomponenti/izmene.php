<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mojabaza";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Konekcija nije uspela: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    die("ID proizvoda nije naveden.");
}
$id = (int)$_GET['id'];
$sql = "SELECT * FROM proizvodi WHERE id = $id";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    die("Proizvod nije pronađen.");
}
$proizvod = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Izmena proizvoda</title>
    <link rel="stylesheet" href="style.css">
   
            
</head>
<body>

<div class="product product-edit">
    <img src="img/<?php echo htmlspecialchars($proizvod['slika']); ?>" alt="<?php echo htmlspecialchars($proizvod['naziv']); ?>">
    <h3><?php echo htmlspecialchars($proizvod['naziv']); ?></h3>
    <p class="price"><?php echo number_format($proizvod['cena'], 2, ',', '.'); ?> RSD</p>
</div>


<div class="form-container">
    <h2>Izmeni proizvod</h2>
    <form action="izmeni_proizvod.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $proizvod['id']; ?>">

        <label for="naziv">Naziv proizvoda</label>
        <input type="text" name="naziv" id="naziv" value="<?php echo htmlspecialchars($proizvod['naziv']); ?>" required>

        <label for="cena">Cena (RSD)</label>
        <input type="number" step="0.01" name="cena" id="cena" value="<?php echo (float)$proizvod['cena']; ?>" required>

        <label for="slika">Izmeni sliku (opciono):</label>
        <input type="file" name="slika" id="slika" accept="img/*">

        <button type="submit">Sačuvaj izmene</button>
    </form>
</div>

</body>
</html>

