<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>O nama</title>
    <link rel="stylesheet" href="style.css"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

    
      <nav class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Logo" class="logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Početna</a></li>
            <li><a href="korisnik.php">Proizvodi</a></li>
            <li><a href="onama.php">O nama</a></li>
            <li><a href="kontakt.php">Kontakt</a></li> 
           
        
        </ul>
    </nav>
    <main style="padding: 80px 20px; max-width: 1000px; margin: auto; background-color: white; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1);">
        <h1 style="text-align: center; color: #333; margin-bottom: 160px;">O nama</h1>
        <p style="font-size: 18px; color: #555; margin-bottom: 20px;">
        <strong>Komponente shop.rs</strong> je specijalizovana online prodavnica računarskih komponenti, osnovana 2020. godine u Beogradu.
        </p>
        <p style="font-size: 18px; color: #555; margin-bottom: 20px;">
            Naša ideja je bila jednostavna – omogućiti svima da lako, brzo i sigurno kupe kvalitetne komponente po pristupačnim cenama, bez obzira na to gde se nalaze u Srbiji.
        </p>

        <p style="font-size: 18px; color: #555; margin-bottom: 20px;">
            Danas, poslujemo isključivo online, ali sa opcijom ličnog preuzimanja u Beogradu. Sve narudžbine isporučujemo brzom kurirskom službom na teritoriji cele Srbije.
        </p>

        <h2 style="color: #333; margin-top: 40px;">Naša misija</h2>
        <p style="font-size: 18px; color: #555; margin-bottom: 20px;">
            Težimo da budemo vaš prvi izbor kada su u pitanju pouzdanost, stručna podrška i fer cene. Svaki kupac nam je važan, i zato ulažemo dodatni trud u korisničku podršku i sigurnost pri kupovini.
        </p>

        <h2 style="color: #333; margin-top: 40px;">Lokacija</h2>
        <p style="font-size: 18px; color: #555;">
            ✔ Sedište: Beograd 
            <br>✔ Dostava: širom Srbije  
            <br>✔ Lično preuzimanje: uz prethodni dogovor
        </p>
   
   <img src="img/location.png" alt= "Naš tim" style="display: block; margin: 20px auto 0 auto; max-width: 50%; border-radius: 10px;">
    </main>
   
   
    <footer class="footer">
        <p>&copy; 2025 Prodavnica Komponenti</p>
    </footer>

    <script>
        function toggleMenu() {
            const navLinks = document.getElementById("navLinks");
            navLinks.classList.toggle("active");
        }
    </script>
</body>
</html>

